public enum PreyState
{
    POSSESED,
    WANDERING,
    GATHERING,
}
