public enum PredatorState
{
    POSSESED,
    WANDERING,
    HUNTING,
}